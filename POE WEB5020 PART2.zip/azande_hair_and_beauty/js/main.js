/**
 * ============================================
 * AZANDE HAIR & BEAUTY - MAIN JAVASCRIPT
 * Professional | Pure JavaScript | No Dependencies
 * With Sidebar Navigation
 * ============================================
 */

(function() {
    'use strict';

    // ============================================
    // 1. SIDEBAR TOGGLE
    // ============================================
    function initSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        const openBtn = document.getElementById('sidebarOpen');
        const closeBtn = document.getElementById('sidebarClose');

        function openSidebar() {
            if (sidebar) sidebar.classList.add('open');
            if (overlay) overlay.classList.add('open');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            if (sidebar) sidebar.classList.remove('open');
            if (overlay) overlay.classList.remove('open');
            document.body.style.overflow = '';
        }

        if (openBtn) {
            openBtn.addEventListener('click', openSidebar);
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', closeSidebar);
        }

        if (overlay) {
            overlay.addEventListener('click', closeSidebar);
        }

        // Close sidebar on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeSidebar();
            }
        });

        // Close sidebar when a nav link is clicked (mobile)
        if (sidebar) {
            sidebar.querySelectorAll('.sidebar-nav a').forEach(function(link) {
                link.addEventListener('click', function() {
                    if (window.innerWidth < 992) {
                        closeSidebar();
                    }
                });
            });
        }
    }

    // ============================================
    // 2. FAQ ACCORDION
    // ============================================
    function initFaqAccordion() {
        const faqItems = document.querySelectorAll('.faq-item');

        faqItems.forEach(function(item) {
            const question = item.querySelector('.question');
            if (question) {
                question.addEventListener('click', function() {
                    const isOpen = item.classList.contains('open');

                    faqItems.forEach(function(other) {
                        if (other !== item) {
                            other.classList.remove('open');
                        }
                    });

                    if (isOpen) {
                        item.classList.remove('open');
                    } else {
                        item.classList.add('open');
                    }
                });
            }
        });

        if (faqItems.length > 0) {
            faqItems[0].classList.add('open');
        }
    }

    // ============================================
    // 3. HAIRSTYLES TAB SWITCHING
    // ============================================
    function initHairstyleTabs() {
        const tabs = document.querySelectorAll('.tab-btn');
        const contents = document.querySelectorAll('.tab-content');

        if (tabs.length === 0) return;

        tabs.forEach(function(tab) {
            tab.addEventListener('click', function() {
                const target = this.dataset.tab;

                tabs.forEach(function(t) {
                    t.classList.remove('active');
                    t.classList.add('inactive');
                });
                this.classList.add('active');
                this.classList.remove('inactive');

                contents.forEach(function(content) {
                    content.classList.remove('active');
                    if (content.id === target) {
                        content.classList.add('active');
                    }
                });
            });
        });
    }

    // ============================================
    // 4. CONTACT FORM HANDLING
    // ============================================
    function initContactForm() {
        const form = document.getElementById('contactForm');
        if (!form) return;

        form.addEventListener('submit', function(e) {
            e.preventDefault();

            const name = document.getElementById('contactName')?.value.trim();
            const email = document.getElementById('contactEmail')?.value.trim();
            const phone = document.getElementById('contactPhone')?.value.trim();
            const message = document.getElementById('contactMessage')?.value.trim();

            if (!name || !email || !message) {
                alert('Please fill in all required fields.');
                return;
            }

            if (!isValidEmail(email)) {
                alert('Please enter a valid email address.');
                return;
            }

            const whatsappMessage = encodeURIComponent(
                'Hello Azande,\n\n' +
                'I have a question regarding your services.\n\n' +
                'Name: ' + name + '\n' +
                'Email: ' + email + '\n' +
                'Phone: ' + (phone || 'Not provided') + '\n\n' +
                'Message:\n' + message
            );

            const phoneNumber = '27614964840';
            window.open('https://wa.me/' + phoneNumber + '?text=' + whatsappMessage, '_blank');

            form.reset();
            showToast('Message sent via WhatsApp! Azande will respond shortly.');
        });
    }

    // ============================================
    // 5. BOOKING FORM HANDLING
    // ============================================
    function initBookingForm() {
        const form = document.getElementById('bookingForm');
        if (!form) return;

        const whatsappBtn = form.querySelector('.whatsapp-btn');
        if (whatsappBtn) {
            whatsappBtn.addEventListener('click', function(e) {
                e.preventDefault();

                const name = document.getElementById('fullName')?.value.trim();
                const phone = document.getElementById('phone')?.value.trim();
                const hairstyle = document.getElementById('hairstyle')?.value;
                const date = document.getElementById('preferredDate')?.value;
                const time = document.getElementById('preferredTime')?.value;
                const serviceType = document.getElementById('serviceType')?.value;
                const hairpiece = document.getElementById('hairpieceNeeded')?.value;
                const notes = document.getElementById('notes')?.value.trim();

                if (!name || !phone || !hairstyle || !date || !time) {
                    alert('Please fill in all required fields.');
                    return;
                }

                let message = 'Hello Azande,\n\nI would like to book a braiding appointment.\n\n';
                if (name) message += 'Name: ' + name + '\n';
                if (phone) message += 'Phone: ' + phone + '\n';
                if (hairstyle) message += 'Hairstyle: ' + hairstyle + '\n';
                if (date) message += 'Preferred Date: ' + date + '\n';
                if (time) message += 'Preferred Time: ' + time + '\n';
                if (serviceType) message += 'Service Type: ' + serviceType + '\n';
                if (hairpiece) message += 'Hairpiece Needed: ' + hairpiece + '\n';
                if (notes) message += '\nAdditional Notes:\n' + notes;

                message += '\n\nPlease confirm availability. Thank you!';

                const encodedMessage = encodeURIComponent(message);
                const phoneNumber = '27614964840';
                window.open('https://wa.me/' + phoneNumber + '?text=' + encodedMessage, '_blank');

                showToast('Opening WhatsApp... Please send your booking request.');
            });
        }
    }

    // ============================================
    // 6. EMAIL VALIDATION HELPER
    // ============================================
    function isValidEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // ============================================
    // 7. TOAST NOTIFICATION
    // ============================================
    function showToast(message) {
        var toast = document.getElementById('toastContainer');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'toastContainer';
            toast.style.cssText = `
                position: fixed;
                bottom: 24px;
                right: 24px;
                background: #111;
                color: #fff;
                padding: 16px 24px;
                border-radius: 12px;
                font-size: 14px;
                max-width: 400px;
                z-index: 9999;
                box-shadow: 0 8px 32px rgba(0,0,0,0.2);
                transform: translateY(100px);
                opacity: 0;
                transition: all 0.4s ease;
                font-family: 'Inter', sans-serif;
            `;
            document.body.appendChild(toast);
        }

        toast.textContent = message;
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';

        clearTimeout(toast._hideTimeout);
        toast._hideTimeout = setTimeout(function() {
            toast.style.transform = 'translateY(100px)';
            toast.style.opacity = '0';
        }, 4000);
    }

    // ============================================
    // 8. ACTIVE NAVIGATION LINK
    // ============================================
    function setActiveNavLink() {
        var currentPage = window.location.pathname.split('/').pop() || 'index.html';
        var links = document.querySelectorAll('.header-nav a, .sidebar-nav a');

        links.forEach(function(link) {
            var href = link.getAttribute('href');
            if (href === currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // ============================================
    // 9. SMOOTH SCROLL FOR ANCHOR LINKS
    // ============================================
    function initSmoothScroll() {
        var links = document.querySelectorAll('a[href^="#"]');
        links.forEach(function(link) {
            link.addEventListener('click', function(e) {
                var targetId = this.getAttribute('href');
                if (targetId === '#') return;

                var target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    var navbarHeight = document.querySelector('.header')?.offsetHeight || 80;
                    var targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navbarHeight;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }

    // ============================================
    // 10. NAVBAR SCROLL EFFECT
    // ============================================
    function initNavbarScroll() {
        var header = document.querySelector('.header');
        var lastScroll = 0;

        window.addEventListener('scroll', function() {
            var currentScroll = window.pageYOffset;

            if (currentScroll > 100) {
                header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.08)';
            } else {
                header.style.boxShadow = '0 2px 12px rgba(0,0,0,0.06)';
            }

            lastScroll = currentScroll;
        });
    }

    // ============================================
    // 11. PHONE NUMBER CLICK TRACKING
    // ============================================
    function initPhoneTracking() {
        var phoneLinks = document.querySelectorAll('a[href^="tel:"]');
        phoneLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                console.log('Phone call initiated to: ' + this.getAttribute('href'));
            });
        });
    }

    // ============================================
    // 12. DATE INPUT MIN VALUE (today)
    // ============================================
    function initDateInputs() {
        var dateInputs = document.querySelectorAll('input[type="date"]');
        var today = new Date().toISOString().split('T')[0];
        dateInputs.forEach(function(input) {
            input.setAttribute('min', today);
        });
    }

    // ============================================
    // 13. INITIALIZE ALL FUNCTIONS
    // ============================================
    function init() {
        setActiveNavLink();
        initSidebar();
        initFaqAccordion();
        initHairstyleTabs();
        initContactForm();
        initBookingForm();
        initSmoothScroll();
        initNavbarScroll();
        initPhoneTracking();
        initDateInputs();

        console.log('Azande Hair & Beauty — Professional Website');
        console.log('© 2026 All Rights Reserved');
        console.log('Partnered with Darling');
    }

    // ============================================
    // 14. DOM READY
    // ============================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
